/** Automatically generated file. DO NOT MODIFY */
package com.skplanet.openplatform.testproject;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}