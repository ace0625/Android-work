package com.skplanet.openplatform.testproject;

public class Const {
	public static String SERVER = "https://apis.skplanetx.com";
	public static String SERVER_PUBLIC = "http://apis.skplanetx.com";
}
 