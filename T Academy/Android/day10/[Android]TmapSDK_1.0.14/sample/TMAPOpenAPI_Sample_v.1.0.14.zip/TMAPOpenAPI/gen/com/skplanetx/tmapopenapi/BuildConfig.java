/** Automatically generated file. DO NOT MODIFY */
package com.skplanetx.tmapopenapi;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}